 /* metricMatch()
    * Checks if two lines of text have the same metric scheme
    * TODO: implement properly to make it less restrictive
    */
   private boolean metricMatch(String lineA, String lineB) {
      boolean result = true;
      int count = 0;
      char A;
      char B;
      lineA = metricCode(lineA);
      lineB = metricCode(lineB);
      if (lineA.length() == lineB.length()) {
         for (int i = 0; i < lineA.length(); i++) {           
            A = lineA.charAt(i);
            B = lineB.charAt(i);
            if (((A=='0') && (B=='1')) || ((A=='1') && (B=='0'))) {
               result = false;
            }
            else {
               if (  ((A=='O') && ((B=='1') || (B=='I')))
                  || ((A=='I') && ((B=='0') || (B=='O')))
                  || ((A=='0') &&  (B=='I'))
                  || ((A=='1') &&  (B=='O'))) {
                  count++;
               }
            }
         }
         if (count > module.getMetricTolerance()) result = false;
      }
      else {result = false;}
      return result;  
   }


//bcGenerator.java

//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\72_battlecry\src\main\java\bcry