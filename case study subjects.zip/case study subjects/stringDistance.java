 private static int stringDistance(String a, String b) {
        int n = a.length();
        int m = b.length();
        int c[][] = new int[n+1][m+1];

        for (int i=0; i<n+1; i++)
            c[i][0] = i;
        for (int j=0; j<m+1; j++)
            c[0][j] = j;

        for (int i=1; i<n+1; i++) {
            for (int j=1; j<m+1; j++) {
                int x = c[i-1][j] + 1;
                int y = c[i][j-1] + 1;
                int z = c[i-1][j-1];
                if (a.charAt(i-1) != b.charAt(j-1))
                    z++;
                c[i][j] = Math.min(Math.min(x, y), z);
            }
        }

        return c[n][m];
    }

//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\35_corina\src\main\java\corina
//Species.java