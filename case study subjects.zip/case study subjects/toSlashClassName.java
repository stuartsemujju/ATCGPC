public static String toSlashClassName (String name)
	{
		char[] nameChars = name.toCharArray();
		StringBuffer sb = new StringBuffer(nameChars.length);
		
		for (int i = 0; i < nameChars.length; i++)
		{
			if ('.' == nameChars[i])
				sb.append('/');
			else
				sb.append(nameChars[i]);
		}
		
		return sb.toString();
	}



//MultiResourceBundle.java

//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\78_caloriecount\src\main\java\com\lts\util