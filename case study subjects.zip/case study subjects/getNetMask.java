    /**
     *  Gets the netmask from a binary representation of number of IP addresses
     *
     *  @param      binaryIP     binary representation of number of IP addresses
     *  @return     netmask of <code>binaryIP</code>
     */
    private String getNetmask(String binaryIP){
        String invertedIPPrefix = "";
        for (int i = 0; i < MAXPREFIX; i++){
            if (binaryIP.charAt(i) == '0')
                invertedIPPrefix += "1";
            else
                invertedIPPrefix += "0";
        }
        return invertedIPPrefix;
    }

//BinaryCalculate

//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\82_ipcalculator\src\main\java\ipac