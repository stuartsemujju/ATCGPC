 public boolean parseString(String inputs){

         v = new Float[(int)period.getConstantFValue()];

         String temp = "";
         char ch;
         int j = 0;
         try{
             for(int i=0 ; i <inputs.length() ; i++){
                  ch = inputs.charAt(i);
                  if (ch == ' ' || ch == ','){
                          if (!temp.equals("")){
                                v[j] = new Float(temp);
                                temp="";
                                j++;
                          }
						  
						  else {
							  
							  
						  }
                  }
                  else
                      temp += ch;
             }
             v[j] = new Float(temp);
         }
         catch(NullPointerException npe){
            return false;
         }

         if (j == (v.length-1) ) return true;
         else    return false;
    }

//Discrete.java

//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\10_water-simulator\src\main\java\simulator\util