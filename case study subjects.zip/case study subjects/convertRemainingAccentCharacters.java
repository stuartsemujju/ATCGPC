private static void convertRemainingAccentCharacters(final StringBuilder decomposed) {
       
	   for (int i = 0; i < decomposed.length(); i++) {
            
			if (decomposed.charAt(i) == '\u0141') { //321
                
            }

			else if (decomposed.charAt(i) == '\u0142') { //322
                
            }
			else {   
			}
        }
    }
	//src/main/java./org/apache/commons/lang3/StringUtils.java /convertRemainingAccentCharacters