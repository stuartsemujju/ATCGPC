
    public String stripString(String allowedChars, String string) {
        StringBuffer returnString = new StringBuffer();
        String validString = allowedChars;
        char checkChar;
        for (int x = 0; x < string.length(); x++) {
            checkChar = string.charAt(x);
            if (validString.indexOf(checkChar) != -1) {
                returnString.append(checkChar);
            }
        }
        return returnString.toString();
    }


//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\2_a4j\src\main\java\net\kencochrane\a4j\util
//a4jUtil.java