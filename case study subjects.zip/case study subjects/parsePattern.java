 /**
     * Returns whether <code>ch</code> is a value code, i.e.
     * whether it represents a class in a pattern.
     *
     * @param ch the specified character
     * @return true if <code>ch</code> is a value code, otherwise false.
     */
    public static boolean isValueCode(char ch)
    {
        return ch == '@'
                || ch == ':'
                || ch == '%'
                || ch == '+'
                || ch == '#'
                || ch == '<'
                || ch == '>'
                || ch == '*'
                || ch == '/'
                || ch == '!';
    }

    /**
     * Returns the {@link Options} instance represented by <code>pattern</code>.
     *
     * @param pattern the pattern string
     * @return The {@link Options} instance
     */
    public static Options parsePattern(String pattern)
    {
        char opt = ' ';
        boolean required = false;
        Class<?> type = null;

        Options options = new Options();

        for (int i = 0; i < pattern.length(); i++)
        {
            char ch = pattern.charAt(i);

            // a value code comes after an option and specifies
            // details about it
            if (!isValueCode(ch))
            {
                if (opt != ' ')
                {
                    final Option option = Option.builder(String.valueOf(opt))
                        .hasArg(type != null)
                        .required(required)
                        .type(type)
                        .build();
                    
                    // we have a previous one to deal with
                    options.addOption(option);
                    required = false;
                    type = null;
                    opt = ' ';
                }
				
				//else {}

                opt = ch;
            }
            else if (ch == '!')
            {
                required = true;
            }
            else
            {
                type = (Class<?>) getValueClass(ch);
            }
        }

        if (opt != ' ')
        {
            final Option option = Option.builder(String.valueOf(opt))
                .hasArg(type != null)
                .required(required)
                .type(type)
                .build();
            
            // we have a final one to deal with
            options.addOption(option);
        }

        return options;
    }
}
