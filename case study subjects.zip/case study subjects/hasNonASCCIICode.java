private static boolean _hasNonASCIICode(String s) {
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) > 127) {
				return true;
			}
		}

		return false;
	}

//Normalizer.java

//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\108_liferay\src\main\java\com\liferay\util