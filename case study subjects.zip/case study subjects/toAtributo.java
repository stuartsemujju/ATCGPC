    public static String toAtributo(String nome) {
        for (int i = 0; i < nome.length(); i++) {
            if (nome.charAt(i) == '_') {
                if (i == nome.length() - 1) {
                    nome = nome.substring(0, i);
                } else {
                    nome = nome.substring(0, i) +
                            nome.substring(i + 1, i + 2).toUpperCase() +
                            nome.substring(i + 2, nome.length());
                    i--;
                }
            }
        }
        return nome;
    }


//Conversor.java

//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\87_jaw-br\src\main\java\jaw\util