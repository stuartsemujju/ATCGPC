//StringUtils.java


	public static boolean containsCharacters (String s, String delims)
	{
		char[] ca = delims.toCharArray();
		for (int i = 0; i < ca.length; i++)
		{
			if (-1 != s.indexOf(ca[i]))
				return true;
		}
		
		return false;
	}

//C:\Users\Stuart\Desktop\sf110\SF110-20130704-src\78_caloriecount\src\main\java\com\lts\util